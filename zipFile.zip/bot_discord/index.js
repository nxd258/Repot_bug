const { Client, GatewayIntentBits } = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
  ]
});

client.on("ready", () => {
  console.log(`Bot đã online với tên: ${client.user.tag}`);
});

client.login("MTQ0Mzg4MzQzMTg5MjM1MzE1NA.G7C5o1.syl6KCgC_iRAcwLuarcyw2tOraStT225-MbwAo");

